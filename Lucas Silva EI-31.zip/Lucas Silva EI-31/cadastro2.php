<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400..900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/style.css">

    <title>Axé Store | Acesso</title>
</head>

<body class="auth-shell">

    <div class="auth-grid">

        <div class="auth-brand">
            <h1>FINALIZAR</h1>
            <p>Crie seu login e senha para acessar o sistema</p>
        </div>

        <div class="auth-panel">

            <form class="auth-form" action="processamento/salvar_login.php" method="POST">

                <h2>CRIAR ACESSO</h2>

                <div class="input-group">
                    <label>LOGIN</label>
                    <input type="text" name="login" required>
                </div>

                <div class="input-group">
                    <label>SENHA</label>
                    <input type="password" name="senha" required>
                </div>

                <button type="submit">FINALIZAR CADASTRO</button>

            </form>

        </div>

    </div>

</body>

</html>